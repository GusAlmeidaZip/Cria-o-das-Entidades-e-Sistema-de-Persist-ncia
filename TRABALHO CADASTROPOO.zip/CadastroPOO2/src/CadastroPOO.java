import model.*;
import java.util.*;
import java.io.*;

public class CadastroPOO {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PessoaFisicaRepo repoFisica = new PessoaFisicaRepo();
        PessoaJuridicaRepo repoJuridica = new PessoaJuridicaRepo();

        int opcao;
        do {
            System.out.println("\n--- Menu ---");
            System.out.println("1 - Incluir");
            System.out.println("2 - Alterar");
            System.out.println("3 - Excluir");
            System.out.println("4 - Exibir pelo ID");
            System.out.println("5 - Exibir todos");
            System.out.println("6 - Salvar dados");
            System.out.println("7 - Recuperar dados");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opcao: ");
            opcao = Integer.parseInt(sc.nextLine());

            switch (opcao) {
                case 1 -> { // Incluir
                    System.out.print("Tipo (F - Fisica, J - Juridica): ");
                    String tipo = sc.nextLine();
                    if (tipo.equalsIgnoreCase("F")) {
                        System.out.print("ID: "); int id = Integer.parseInt(sc.nextLine());
                        System.out.print("Nome: "); String nome = sc.nextLine();
                        System.out.print("CPF: "); String cpf = sc.nextLine();
                        System.out.print("Idade: "); int idade = Integer.parseInt(sc.nextLine());
                        repoFisica.inserir(new PessoaFisica(id, nome, cpf, idade));
                    } else {
                        System.out.print("ID: "); int id = Integer.parseInt(sc.nextLine());
                        System.out.print("Nome: "); String nome = sc.nextLine();
                        System.out.print("CNPJ: "); String cnpj = sc.nextLine();
                        repoJuridica.inserir(new PessoaJuridica(id, nome, cnpj));
                    }
                }
                case 2 -> { // Alterar
                    System.out.print("Tipo (F - Fisica, J - Juridica): ");
                    String tipo = sc.nextLine();
                    System.out.print("ID: "); int id = Integer.parseInt(sc.nextLine());
                    if (tipo.equalsIgnoreCase("F")) {
                        PessoaFisica pf = repoFisica.obter(id);
                        if (pf != null) {
                            pf.exibir();
                            System.out.print("Novo nome: "); pf.setNome(sc.nextLine());
                            System.out.print("Novo CPF: "); pf.setCpf(sc.nextLine());
                            System.out.print("Nova idade: "); pf.setIdade(Integer.parseInt(sc.nextLine()));
                            repoFisica.alterar(pf);
                        }
                    } else {
                        PessoaJuridica pj = repoJuridica.obter(id);
                        if (pj != null) {
                            pj.exibir();
                            System.out.print("Novo nome: "); pj.setNome(sc.nextLine());
                            System.out.print("Novo CNPJ: "); pj.setCnpj(sc.nextLine());
                            repoJuridica.alterar(pj);
                        }
                    }
                }
                case 3 -> { // Excluir
                    System.out.print("Tipo (F - Fisica, J - Juridica): ");
                    String tipo = sc.nextLine();
                    System.out.print("ID: "); int id = Integer.parseInt(sc.nextLine());
                    if (tipo.equalsIgnoreCase("F")) repoFisica.excluir(id);
                    else repoJuridica.excluir(id);
                }
                case 4 -> { // Exibir pelo ID
                    System.out.print("Tipo (F - Fisica, J - Juridica): ");
                    String tipo = sc.nextLine();
                    System.out.print("ID: "); int id = Integer.parseInt(sc.nextLine());
                    if (tipo.equalsIgnoreCase("F")) {
                        PessoaFisica pf = repoFisica.obter(id);
                        if (pf != null) pf.exibir();
                    } else {
                        PessoaJuridica pj = repoJuridica.obter(id);
                        if (pj != null) pj.exibir();
                    }
                }
                case 5 -> { // Exibir todos
                    System.out.print("Tipo (F - Fisica, J - Juridica): ");
                    String tipo = sc.nextLine();
                    if (tipo.equalsIgnoreCase("F")) {
                        for (PessoaFisica pf : repoFisica.obterTodos()) pf.exibir();
                    } else {
                        for (PessoaJuridica pj : repoJuridica.obterTodos()) pj.exibir();
                    }
                }
                case 6 -> { // Salvar
                    System.out.print("Prefixo do arquivo: ");
                    String prefixo = sc.nextLine();
                    try {
                        repoFisica.persistir(prefixo + ".fisica.bin");
                        repoJuridica.persistir(prefixo + ".juridica.bin");
                        System.out.println("Dados salvos.");
                    } catch (Exception e) {
                        System.out.println("Erro ao salvar: " + e.getMessage());
                    }
                }
                case 7 -> { // Recuperar
                    System.out.print("Prefixo do arquivo: ");
                    String prefixo = sc.nextLine();
                    try {
                        repoFisica.recuperar(prefixo + ".fisica.bin");
                        repoJuridica.recuperar(prefixo + ".juridica.bin");
                        System.out.println("Dados recuperados.");
                    } catch (Exception e) {
                        System.out.println("Erro ao recuperar: " + e.getMessage());
                    }
                }
                case 0 -> System.out.println("Finalizando...");
                default -> System.out.println("Opcao invalida!");
            }
        } while (opcao != 0);

        sc.close();
    }
}
