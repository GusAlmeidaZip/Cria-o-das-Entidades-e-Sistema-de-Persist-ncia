import model.PessoaFisica;
import model.PessoaFisicaRepo;
import model.PessoaJuridica;
import model.PessoaJuridicaRepo;

public class CadastroPOO {
    public static void main(String[] args) {
        try {
            // Repositório de Pessoas Físicas (repo1)
            PessoaFisicaRepo repo1 = new PessoaFisicaRepo();

            // Adicionando duas pessoas físicas
            PessoaFisica pf1 = new PessoaFisica(1, "Ana", "11111111111", 25);
            PessoaFisica pf2 = new PessoaFisica(2, "Carlos", "22222222222", 52);
            repo1.inserir(pf1);
            repo1.inserir(pf2);

            // Persistência
            String arquivoPF = "pessoas_fisicas.dat";
            repo1.persistir(arquivoPF);
            System.out.println("Dados de Pessoa Fisica Armazenados.");

            // Recuperação
            PessoaFisicaRepo repo2 = new PessoaFisicaRepo();
            repo2.recuperar(arquivoPF);
            System.out.println("Dados de Pessoa Fisica Recuperados.");
            for (PessoaFisica pf : repo2.obterTodos()) {
                System.out.println("Id: " + pf.getId());
                System.out.println("Nome: " + pf.getNome());
                System.out.println("CPF: " + pf.getCpf());
                System.out.println("Idade: " + pf.getIdade());
            }

            // Repositório de Pessoas Jurídicas (repo3)
            PessoaJuridicaRepo repo3 = new PessoaJuridicaRepo();

            // Adicionando duas pessoas jurídicas
            PessoaJuridica pj1 = new PessoaJuridica(3, "XPTO Sales", "33333333333333");
            PessoaJuridica pj2 = new PessoaJuridica(4, "XPTO Solutions", "44444444444444");
            repo3.inserir(pj1);
            repo3.inserir(pj2);

            // Persistência
            String arquivoPJ = "pessoas_juridicas.dat";
            repo3.persistir(arquivoPJ);
            System.out.println("Dados de Pessoa Juridica Armazenados.");

            // Recuperação
            PessoaJuridicaRepo repo4 = new PessoaJuridicaRepo();
            repo4.recuperar(arquivoPJ);
            System.out.println("Dados de Pessoa Juridica Recuperados.");
            for (PessoaJuridica pj : repo4.obterTodos()) {
                System.out.println("Id: " + pj.getId());
                System.out.println("Nome: " + pj.getNome());
                System.out.println("CNPJ: " + pj.getCnpj());
            }

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
